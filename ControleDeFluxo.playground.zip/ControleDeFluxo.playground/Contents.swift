import UIKit

/*
 

for objetoDeLeitura in colecaoOuSequenciaASerUtilizada {
    // Bloco de execução a ser repetido para todos os itens da sequencia
}
*/

// (...) open range e temos também o half-open range (..<)

for semana in 1...7 {
    print(semana)
}

for meses in 1..<13 {
    print(meses)
}

// For-in para fazer a leitura de uma coleção do tipo array

let diasDaSemana = ["Seg", "Ter", "Qua", "Qui", "Sex", "Sab", "Dom"]

for mostrarDia in diasDaSemana {
    print(mostrarDia)
}

// Fazer um for-in com index 1...5 print \()

for number in 1...5 {
    print("\(number) vezes 5 é \(number*5)")
}

// Acessando itens of an array
let languages = ["Swift", "Java", "Go", "JavaScript"]

for linguagens in languages where linguagens != "JavaScript" {
    print(linguagens)
}

// Para acrescentar itens por um valor fixo, como por exemplo 2 em cada itinerário em vez de um range, usamos a função stride(from: to: by):

for i in stride(from: 0, to: 12, by: 2) {
    print(i)
}

let pais : [String] = ["Brasil", "Japão", "Paquistão", "Moldávia", "Zimbabwe", "Nauru", "Casaquistão"]

for index in stride(from: 0, to: pais.count, by: 2) {
    print(pais[index])
}

var numbers = [1,2,3,4,5,6,7,8,9,10,11,12,13]

func addNumbersByStride() {
    let output = stride(from: numbers[0], through: numbers[14], by: 2)
    
    print(output)
}

let brasileirao2020 : [Int:String] = [1: "Flamengo", 2: "Internacional", 3: "Atlético-MG", 4: "São Paulo", 5: "Fluminense", 6: "Gremio", 7: "Palmeiras", 8: "Santos", 9: "Athlético-PR", 10: "RB Bragantino", 11: "Ceará", 12: "Corinthians", 13: "Atlético-GO", 14: "Bahia", 15: "Sport", 16: "Fortaleza", 17: "Vasco", 18: "Goiás", 19: "Coritiba", 20: "Botafogo"]

for times in stride(from: 1, to: brasileirao2020.count, by: 1) {
    print(brasileirao2020[times]!)
}

// While e repeat while

// While assim com o for é uma estrutura de repetição. É responsável por executar um bloco de instruções enquanto a sua condição for verdadeira.

/*
// sintaxe do while
while condicao {
    // Bloco de execução
    // Tratamento de parada de execução
}
*/

// Um contador que fará uma contagem regressiva de 100 a 1.

var contador = 100

while contador > 0 {
    print(contador)
    
    //tratamento de parada
    contador -= 1
}

// Non while se não colocarmos o tratamento de parada da execução o processo em loop infinito. Isso pode gerar inconistencia na sua aplicação.

// A diferença é que primeiro será executado o tratamento de parada, para somente depois verificar a condição. Ao contrário do while, que verifica a condição para depois procurar qual o tratamento de parada.

// repeat while sintax

var numeroPensado = 3
var numeroComputador = Int()
var tentativas = 0

repeat {
    tentativas += 1
    numeroComputador = Int(arc4random_uniform(10))
} while (numeroPensado != numeroComputador) && (tentativas <= 10)
    if tentativas < 11 {
        print("Voce acerto em \(tentativas) de vezes!")
    } else {
        print("Voce errou todas as tentativas")
    }

var currentLevel : Int = 0
var  finalLevel : Int = 5
let gameCompleted = true

repeat {
    //Jogando o game
    if gameCompleted {
        print("Voce passou essa fase do jogo \(currentLevel)!")
        currentLevel += 1
    }
} while (currentLevel <= finalLevel)
    print("Fora do loop")

