import UIKit

// Operadores de Comparação

// a == b Valor de a é igual ao valor de b

// a != b Valor de a é diferente ao valor de b

// a < b Valor de a é menor ao valor de b

// a > b Valor de a é maior ao valor de b

// a <= b Valor de a é menor ou igual ao valor de b

// a >= b Valor de a é maior ou igual ao valor de b

// a === b Os objetos são identicos (referencia dos obejtos)

// a !== b Os objetos são diferentes (referencia dos objetos)

var a = 1
var b = 3

print(a == b)
print(a != b)
print(a > b)
print(a < b)

// (Condição) ? acaoVerdadeira : acaoFalsa

var name = "Geraldo"

var resultado = (name == "Geraldo") ? "Seja bem-vindo" : "Desconhecido"
print(resultado)

// Exemplo de Variável inicializada e vazia

var nome : String = ""
var sobrenome = String()

// Sintaxe de declaração de forma explícita e vazia de uma Array:

var arrayVazio = [String]()

// Array com tipagem explícita e com dados

var arrayComTipagemExplicita : [String] = ["Mário", "Sonic", "Crash"]
print(arrayComTipagemExplicita)

// Array com tipagem implícita e com dados

var arrayComTipagemImplicita = [15, 24, 13, 30]
print(arrayComTipagemImplicita)
