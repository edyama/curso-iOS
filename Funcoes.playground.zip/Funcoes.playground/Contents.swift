import UIKit

// Função são usadas para execeutar uma mesma funcionalidade diversas vezes. Podem ser chamadas sempre que necesário no código, evitando assim repetições desnecessárias.

// Sintaxe de uma função em Swift

/*
func nomeDaFuncao (parametro: tipo de parametro) -> tipo de retorno {
    // Bloco de retorno
    return dado
}
*/

func cumprimento(user: String) {
    print("Bom dia, \(user)!")
}

cumprimento(user: "Gil Brother Away")
cumprimento(user: "Detonator")
cumprimento(user: "Blonde Hammer")

func minhaPrimeiraFuncao() {
    print("Minha primeira função com Swift!")
}

minhaPrimeiraFuncao()

/*
 func funcNome() -> Void {
 
 }
 
 func funcNome2() {
 
 }
 
 func funcNome3() -> () {
 
 }
 */
