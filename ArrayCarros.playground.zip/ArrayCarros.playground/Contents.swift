import UIKit

var carros : [String] = ["Gol", "Fusca", "Corsa", "Compass"]

print(carros)

// append é utilizado para adicionar itens a uma array
carros.append("Palio")
carros.append("Onix")
carros.append("Camaro")

print(carros)

// insert para adicionar um item a um determinado índice de uma array

carros.insert("Kombi", at: 0)

print(carros)

// Substituir o valor de um índice

carros[1] = "HB20"

print(carros)

// Criar uma Array de frutas que contenha 6 tipos de frutas distintas. Após isso, adicionar abacaxi ao ínidce 0 (zero). Substituir o índice 4 por morango e remover o índice 6.
var frutas : [String] = ["Uva","Cajá","Caju","Lichia","Goiaba","Romã"]

print(frutas)
frutas[0] = "Abacaxi"
frutas[3] = "Morango"
frutas.remove(at: 5)
print(frutas)

// Tuplas - Mesmo tipo

var empresa = ("Apple", "iOS", "Swift")

print(empresa.0)
print(empresa.1)
print(empresa.2)

/*
empresa = (String, String, String) {
    0 = "Apple"
    1 = "iOS"
    2 = "Swift"
}
*/

// Declaração de uma tupla com tipos diferentes

var pessoa = ("Pedro Álvares Cabral", 40, 87.3)

/*
pessoa = (String, Int, Double) {
    0 = "Pedro Álvares Cabral"
    1 = 40
    2 = 87.3
}
*/

print(pessoa.2)
pessoa.1
pessoa.0

// Atribuindo nomes aos elementos de uma Tupla

var ferrariEnzo = (cilindros: "V12", potencia: 660)

print(ferrariEnzo.cilindros)
ferrariEnzo.potencia
ferrariEnzo.1 = 400
ferrariEnzo.0 = "V8"
print(ferrariEnzo)

// Criar uma tupla chamada "usuario" contendo? email(String), password(Int), tipoDeUsuario(String: aluno ou professor). Fazer o print de cada elemento da tupla. Substituir o elemento usuario de aluno para professor.

var usuario = (email: "jorgepoliva@bol.com.br", password: "polivao123", tipoDeUsuario: "aluno")

print(usuario.email)
print(usuario.password)
print(usuario.tipoDeUsuario)

usuario.tipoDeUsuario = "professor"
print(usuario.tipoDeUsuario)

/*
Dicion[arios, assim como arrays, podem organizar coleções de dados. No entanto, a sua organização é feita através de um par de dados, o chamado key:value.
 O par key"value liga um valor a uma chave associativa, fazendo assim uma distinção mais completa dos elementos.
*/

// Dicionário - Sintaxe da declaração explícita e vazia

var dicionarioItems = [String: Int]()

// Dicionário com tipagem explícita e com dados

var dicionarioItems1 : [String: Int] = ["chave1": 1, "chave2": 2]

// Dicionario com tipagem implícita e com dados

var dicionarioItems2 = ["chave1": 1, "chave2": 2, "chave3": 3]

// Alterando dados de um dicionário
dicionarioItems2["chave3"] = 4

// Adicionanndo dados de um dicionário
dicionarioItems2["chave4"] = 4

print(dicionarioItems2)

// Removendo dados de um dicionário
dicionarioItems2.removeValue(forKey: "chave2")
dicionarioItems2.removeValue(forKey: "chave1")
print(dicionarioItems2)

// 1 - Criar um dicionário de animais contendo 6 animais. 2 - Adicione mais 2 animamis diferentes. 3 - Substituir o animal da chave 3 pelo valor "Cachorro". 4 - Remover o valor da última chave.

var dicionarioAnimais = [1: "Cavalo", 2: "Águia", 3: "Gorila", 4: "Coala", 5: "Lobo", 6: "Papagaio"]

print(dicionarioAnimais)

dicionarioAnimais[7] = "Boi"
dicionarioAnimais[8] = "Serpente"

print(dicionarioAnimais)

dicionarioAnimais[3] = "Cachorro"

print(dicionarioAnimais)

dicionarioAnimais.removeValue(forKey: 8)

print(dicionarioAnimais)
