import UIKit

// Isso é um comentário

/*Aqui inicio o meu comentário
 tudo que for
 digitado aqui
 será considerado
 como comentário
 
 */

// MARK: - Isso é um MARK
var str = "Hello, world!"

str = "Olá, pessoal!"

let cidade = "São Paulo"

//Isso é uma string
let issoEUmaString : String = "String"

//Isso é uma caracter
let character : Character = "A"

//Isso é um Integer
let numeroUm : Int = 1

//Isso é uma Float
let numeroFloat : Float = 25.255

//Isso é uma Double
let numeroDouble : Double = 25.2525252525

//Isso é uma Array de strings in swift
let streets : [String] = ["Rua das Acácias", "Rua dos Flamboyans", "Rua das Rosas"]

//Isso é uma Array de Integers in swift
let numerosImpares : [Int] = [1, 3, 5, 7, 9, 11, 13, 15]

//Isso é um dicionário
let dic = ["nome": "Zeus", "Idade": "79"]
let dic1 = ["nome": ["Kel","Kenan"], "Idade": ["19","20"]]
let numeros = [1: "Um", 2: "Dois", 3: "Tres"]

//Isso é um Boolean
let euSouLegal : Bool = true

//Inicialização de variáveis
var nome = "Eduardo"
print(nome)
nome = "Eduardo Yamagata"
print(nome)

var idade = Int()
idade = 30

var altura = Double()
altura = 1.60
print(altura)

//Isso é interpolação
print("Olá, meu nome é \(nome), eu tenho \(idade)!")

//Isso é uma concatenação
var animal = "Gato"
var tipo = "Tuxedo"

print(animal == tipo)

//Operadores Aritméticos

//Soma
let soma = 2 + 2
print(soma)

//Subtração
let subtracao = 10 - 7
print(subtracao)

//Multiplicação
let multiplicacao = 100 * 5
print(multiplicacao)

//Divisao
let divisao = 200 / 4
print(divisao)

//Resto, porcentagem
let resto = 33 % 5
print(resto)

//Inversão de valores de positivo para negativo
var numeroCem = 100
print(-numeroCem)

var valor = 250
//Valor mais 10

var valorMaisDez = valor + 10
print(valorMaisDez)

let preco : Double = 300

//O preço é igual a preço menos 10.10
var preco1 = preco
preco1 -= 10.10
print(preco1)

//O preço é igual a preço vezes 1.78
var preco2 = preco
preco2 *= 1.78
print(preco2)

//O preço é igual a preço dividido por 3
var preco3 = preco
preco3 /= 3
print(preco3)

//O preço tira resto de 10
var preco4 : Int = 300
preco4 %= 10
print(preco4)
