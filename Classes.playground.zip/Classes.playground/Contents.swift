import UIKit

// A sintaxe de uma classe / class

/*
class NameDaClasse : SuperClasseHerdada {
    // definição da classe com propriedade e métodos
}
 
 Para a nomenclatuda de CLASS, nós utilizamos o estilo de código UpperCamelCase
 
 
*/

// Criando a classe Cor

class Cor {
    
}

let amarelo = Cor()
let vermelho = Cor()
let azul = Cor()

// Criando a classe Animal

class Animal {
    // Propriedades
    
    var peso : Double = 0.0
    var altura : Double = 0.0
    var especie : String = ""
    var idade : Int = 0
    
    // Declaração dos métodos
    func andar(){
        print("Animal andando")
    }
    
    func comer(){
        print("Animal comendo")
    }
    
    // Fechamento do escopo da classe
}

// Inicializando
var gato : Animal = Animal()

gato.andar()
gato.peso = 5.5
gato.altura = 25.1
gato.especie = "Siames"
gato.idade = 5

print("Peso: \(gato.peso)kg\nAltura: \(gato.altura)m\nEspécie: \(gato.especie)\nIdade: \(gato.idade) anos")

// Encapsulamento em Swift:

// Public - permite acesso aos elementos da classe de qualquer outra classe que tenha importando a fonte da sua atualização.

// Internal - permite acesso apenas dentro do próprio escopo (bundle ou pacote).

// Private - permite acesso apenas dentro da classe declarada.

class Pessoa {
    var nome : String = ""
    private var idade : Int = 21
    
    
    func mudarIdade(novaIdade: Int) {
        idade = novaIdade
    }
    
    func imprimeNome(){
        print("Nome: \(nome)")
    }
    
    func imprimeIdade(){
        print("Idade: \(idade)")
    }
}

var humano : Pessoa = Pessoa()
humano.nome = "Francisco"
humano.mudarIdade(novaIdade: 22)
humano.imprimeNome()
humano.imprimeIdade()

// Utilizamos os inits para serem executados no momento que instacionamos a nossa classe. Através deles podemos atribuir valores iniciais às propriedades, executar métodos da classe ou da superclasse e realizar qualquer tipo de rotina necessária no momento da criação do objeto.

// Sintaxe do init

/*
init(){
    
}
*/

class Fahrenheit {
    var temperatura : Double
    init() {
        temperatura = 32.0
    }
}

class Conversor {
    var valorCelsius : Double
    
    init(valorFahrenheit: Double) {
        valorCelsius = (valorFahrenheit - 32.0) / 1.8
    }
}

// Criar uma variável chamada fervuraAgua. Conversão de Fahrenheit para Celsius no valor de 212.0 aonde o resultado vai ser 100.0.

var fervuraAgua = Conversor.init(valorFahrenheit: 212.0)
print("Temperatura fervura água: \(fervuraAgua.valorCelsius)")

// Qual a diferença entre WillSet() e didSet(), Set() e Get()?

// Herança é a capacidade que uma classe tem de captar as propriedade de outra classe. A classe pai é chamada de superclasse e a classe que está herdando chamamos de subclasse.

// Sintaxe

/*
class SubClass : SuperClassHerdada {
    // Definição da classe
}
*/

// Classe Pai - SuperClass humano

class Humano {
    var nome = String()
    var idade = Int()
    
    func andar() {
        print("O humano está andando!")
    }
}

// Classe Filha - SubClass Atleta

class Atleta : Humano {
    var esporte = String()
    var categoria = String()
    
    func indicarLesao() {
        print("O Atleta está lesionado!")
    }
    
    override func andar() {
        print("Estou andando rápido!")
    }
}

// Se criarmos um objeto do tipo Humano, elel não terá acesso ãs propriedades de atleta. Porém se criarmos um objeto do tipo Atleta, por ter herdado as propriedades de Humano, todas as funções e propriedades estão disponíevis para o objeto.
    
let maratonista = Atleta()

// Propriedades herdadas do Humano
maratonista.nome = "João"
maratonista.idade = 30

// Propriedades Herdadas de Atleta
maratonista.esporte = "Atletismo"
maratonista.categoria = "Maratona"

maratonista.indicarLesao()

var donaDeCasa = Humano()
let corredor = Atleta()

maratonista.andar()
donaDeCasa.andar()

// Structs e Classes são estruturas extremamente semelhantes e possume sintaxes bem parecidas também. A declaração de uma Struct é feito com a palavra Struct. Geralmente Structs são utilizadas as características de herança e são instanciadas por valor type.

/*
struct NomeDaEstrutura {
    // Definição da estrutura com propriedades e métodos.
 }
*/

struct Dimensoes {
   var largura = Float()
   var comprimento = Float()
}

// Criar uma variável chamada cozinha. Lagura da cozinha será de 4.35 e o comprimento será de 3.70.

var cozinha = Dimensoes(largura: 4.35, comprimento: 3.70)

print(cozinha.largura)
print(cozinha.comprimento)

// Enum é utilizada quando pensamos em um número finito de possibilidades. Estas possibilidades podem ser padronizadas se forem do mesmo tipo e seu conteúdo não for modificado, adicionado ou retirado.

// Sintaxe de um enum

/*
 enum NomeDeEnumeracao : TipoSeForUtilizar {
    case nomeDoElemento = valorDoElemento
    case nomeDoElemento = valorDoElemento
    case nomeDoElemento = valorDoElemento
    case nomeDoElemento = valorDoElemento
    case nomeDoElemento = valorDoElemento
    case nomeDoElemento = valorDoElemento
 }
 */

enum PontosCardeais : String {
    case Norte = "Vamos para a direção Norte"
    case Sul = "Vamos para a direção Sul"
    case Leste = "Vamos para a direção Leste"
    case Oeste = "Vamos para a direção Oeste"
}

print(PontosCardeais.Norte.rawValue)

enum Semana : Int {
    case Domingo = 100
    case Segunda
    case Terca
    case Quarta
    case Quinta
    case Sexta
    case Sabado
}

print(Semana.Sexta.rawValue)

// Optional Chaining

/* Processo de consulta a propriedades, métodos e subscripts que podem ou não ser nulos.
 
 Se o optional conta o valor, a leitura do elemento é bem sucedida. Se for nulo, a leitura retornará nil - NOT IN LIST.

 */

var matematica: Double? = 9.5
var portugues: Double? = 8.5
var ciencias: Double? = nil
var geografia: Double? = 10

print(ciencias)

// ? Admite qualquer valor, inclusive nulo
// ! "Unwrapperd" Desembrulha o objeto de maneira indiscriminada, esperando a garantia do propgramador.

// Manipulando valores nulos utilizando optional (?)

class Treinamento {
    var titulo: String?
    var duracao: Int?
}

var treinamento1 = Treinamento()
treinamento1.titulo = "Lógica de Programação"
treinamento1.duracao = 32

var treinamento2 = Treinamento()

treinamento2.titulo = "POO"
treinamento2.duracao = nil

// Optional binding fornece uma maneira alternativa para testar e desembrulhar um optional. Com isso, não precisamos utilizar o Forced Unwrapping.

// Sintaxe

/*
if let nomeDaConstante = algumaOpcional {
    // Declaração realizada se o valor for válido
} else {
    // Declaração realizada se o valor for nulo
}
*/

var nome: String? = "José"

if let meuNome = nome {
    print("Meu nome é  \(meuNome)")
} else {
    print("Valor Nulo")
}

// Condicional de falha - guard: o código deve sair do bloco que está sendo executado caso não consiga validar a condição.

func areaQuadrada(valor: Int?){
    guard let num = valor else {
        print("Nenhum valor foi passado")
        return
    }
    print(num * num)
}

areaQuadrada(valor: 10)
areaQuadrada(valor: nil)

// Operador Nil Coalescing

var nome1: String? = nil
var nome2: String? = "Dante Alighieri"

var resultado = nome1 ?? nome2

print(resultado!)

// O que são Subscripts

// O que é uma extension
