import UIKit

// Em if e else nos usamos operadores de compração. Os mais comuns são: <, >, ==, !=.

// Vamos a sintaxe de if/e;se:

/*
 if (expressão lógica) {
    // Caso a expressão seja verdadeira este bloco será executado.
 } else {
    // Caso a opção seja falsa, este bloco será executado.
 }
*/

var valor = 100

if (valor == 100) {
    print("O valor é igual a 100!!!")
}

// Verificar se o valor é diferente de 200
if  (valor != 200) {
    print("O valor é diferente de 200!!!")
}

// O else utilizamos para execução de um dos blocos, ou sjea, um dos caminhos.

var gol = true

if (gol == true) {
    print("Foi gol")
} else {
    print("Continue torecendo")
}

// Podemos também utilizar else if para verificar várias condições em uma mesma estrutura.

var numero = 20

if (numero < 20) {
    print("Menor que 20!!!")
} else if (numero > 20) {
    print("Maior que 20")
} else {
    print("O número é 20!!!")
}

// Checar se o valor é positivo, negativo ou ZERO.

var num1 = 45

if (num1 > 0) {
    print("Número \(num1) é positivo")
} else if (num1 < 0) {
    print("Número \(num1) é negativo")
} else {
    print("O número é ZERO!")
}

// Um comportamento importade de if/else e o uso de operadores AND e OR sua fubnção e criar condições compostas, onde várias condições serão necessárias para decidir o rumo do código. Utilizaremos os símboloes && para AND e || para OR.

// Quando utilizados os operadores && e || existe a obrigatoriedade das duas ou mais expressões sejam confirmadas.

var cupom: Int = 1020
var hora : Int = 11

// Exemplo com &&

if cupom == 1010 && hora < 12 {
    print("Desconto concedido para o cliente \n")
} else {
    print("Não foi possível conceder o desconto dessa vez")
}

// Exemplo com OR (||)

if cupom == 1010 || hora < 12 {
    print("Desconto concedido \n")
} else {
    print("Não é possível conceder o desconto")
}

/*
 true && true // true
 false && true // false
 true && false // false
 false && false // false
 
 true || false // true
 false || false // true
 true || true // true
 false || false // false
 
  true != false // true
  false != true // true
  true != true // false
  false != false // false
  */

 let enteredDoorCode = true
 let passedRetinaScan = false
 if enteredDoorCode && passedRetinaScan {
     print("Welcome!")
 } else {
     print("ACCESS DENIED")
 }
// Prints "ACCESS DENIED"

let hasDoorKey = false
let knowsOverridePassword = true
if hasDoorKey || knowsOverridePassword {
    print("Welcome!")
} else {
    print("ACCESS DENIED")
}


if enteredDoorCode && passedRetinaScan || hasDoorKey || knowsOverridePassword {
    print("Welcome!")
} else {
    print("ACCESS DENIED")
}
// Prints "Welcome"

/*
 
 Outro recurso para implementar condicionais é a estrutura Switch. A diferença em relação ao if/else é a facilidade em fazer comparações sucessivas caso a caso. Se por exemplo, tivéssemos que comparar um valor com 3 possíveis respostas, a abordagem de switch seria mais indicada.


switch valorASerConsiderado {
case valorCaso1:
//bloco a ser considerado se valorCaso1 for verdadeiro
case valorCaso2:
//bloco a ser considerado se valorCaso2 for verdadeiro
case valorCaso3:
//bloco a ser considerado
    
Outro recurso para implementar condicionais é a estrutura Switch. A diferença em relação ao if/else é a facilidade em fazer comparações sucessivas caso a caso. Se por exemplo, tivéssemos que comparar um valor com 3 possíveis respostas, a abordagem de switch seria mais indicada.

switch valorASerConsiderado {
case valorCaso1:
//bloco a ser considerado se valorCaso1 for verdadeiro
case valorCaso2:
//bloco a ser considerado se valorCaso2 for verdadeiro
case valorCaso3:
// bloco a ser considerado
*/

/*
Outro recurso para implementar condicionais é a estrutura Switch. A diferença em relação ao if/else é a facilidade em fazer comparações sucessivas caso a caso. Se por exemplo, tivéssemos que comparar um valor com 3 possíveis respostas, a abordagem de switch seria mais indicada.

switch valorASerConsiderado {
case valorCaso1:
//bloco a ser considerado se valorCaso1 for verdadeiro
case valorCaso2:
//bloco a ser considerado se valorCaso2 for verdadeiro
case valorCaso3:
//bloco a ser considerado
*/

var valor2: Int = 2000

switch valor2 {
  case 1:
print("Não temos muito dinheiro")
case 100:
print("Estamos com algum dinheiro")
case 1000:
print("Estamos bem de dinheiro")
default:
print("Temos \(valor2)")

}


var calculo = 5 * 1
var conta = 2 + 3

switch (calculo < 10, conta == 5) {
case (true, true):
    print("Calculo é menor que  10. A conta da 5!")
case (false, true):
    print("Calculo nao é menor que 10. A conta da 5!")
case (true, false):
    print("Calculo é menor que 10. A conta não dá 5!")
default:
    print("Cálculo nao é menor que 10. A conta não dá 5!")
}

var calculo2 = 5 * 1
var conta2 = 2 + 3

switch (calculo2 < 10, conta2 == 5) {
case (true, true):
    print("Calculo é menor que  10. A conta da 5!")
case (false, true):
    print("Calculo nao é menor que 10. A conta da 5!")
case (true, false):
    print("Calculo é menor que 10. A conta  nao da 5!")
default:
    print("Calculo nao e menor que 10. A conta nao da 5!")
}

// Criar uma variável com dias da semana (Int). Switch para imprimir qual o dia de acordo com o número digitado na variável diasDaSemana(1,2,3,4,5,6,7) ou default(Error - número da semana não encontrado) para qual outro número.

var diasDaSemana = 3

switch (diasDaSemana <= 7) {
case (true):
    print("Dia da semana: \(diasDaSemana)")
default:
    print("Error - número da semana não encontrado")
}
